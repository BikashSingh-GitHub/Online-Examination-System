<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;#820005
}
</style>
   <table > <tr bgcolor="	#4169E1"><td  width="10%">
     <img border="0" src="image/logo.jpg" width="100%" height="150" align="left"><th><h1 style="color:white;" align="center"><b>Welcome to Online Examination</b></h1></th></td>
  </tr>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#5e4fa2" background="img/blackbar.jpg">
  <tr><font size="4px" color="white"><marquee height="25" direction="left" style="background:#0000CD"><b>Welcome Student's to the Online Examination System. This site will take your  online Test/Quiz in MCQ<i> (Multiple Choices Questions)</i> format of various subject your course. Get Exam Ready, All the best. </b></marquee></font>
    <td width="100%"align="right"><img border="0" src="image/blackbar.jpg" width="1517" height="2"></td>
  </Table>
  <Table width="100%">
  <tr>
  <td>
  <?php @$_SESSION['login']; 
  error_reporting(1);
  ?>
  </td>
    <td>
	<?php
	if(isset($_SESSION['login']))
	{
	 echo "<div align=\"right\"><strong><a href=\"index.php\"> Home </a>|<a href=\"signout.php\">Signout</a></strong></div>";
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
	</td>
	
  </tr>
  
</table>
