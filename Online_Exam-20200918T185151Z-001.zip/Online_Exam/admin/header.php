

<style type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>

</style>
<table> <tr bgcolor="darkblue"><td width="10%">
 <img border="0" src="logo.jpg" width="100%" height="150" align="left"><th><h1 style="color:white;" align="center"><b>Welcome to Online Examination</b></h1></th></td>
	</tr>
</table><font size="4px" color="white"><marquee height="25" direction="left" style="background:#4169E1"><b>Welcome Adminstrative of the Online Examination System. This site will provide the fuctionality of conducting online examination in MCQ-(Mulitiple choices questions) format for various subjects of any course.The adminstrative panel has the priviliege to <i> add,delete,insert,update,create-exams</i> for students and view student details. </b></marquee></font>
<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#5e4fa2" background="img/blackbar.jpg">
  <tr>
    <td width="100%"align="right"><img border="0" src="blackbar.jpg" width="1520" height="2"></td>
  </tr>
  </Table>
  <Table width="100%">
  <tr>
  <td>
  <?php @$_SESSION['login']; 
  error_reporting(1);
  ?>
  </td>
    <td>
	
<?php
	if(isset($_SESSION['alogin']))
	{
	
	 echo "<h4 class='text-success text-center btn btn-success'>
	 <div align=\"left\"><strong>
	 <a href=\"viewsub.php\">  view Subject</a>&emsp;&emsp;
		<a href=\"testview.php\"> view Test</a>&emsp;&emsp;  
	 <a href=\"questiondelete.php\">View Question</a>&emsp;&emsp;
	 <a href=\"showuser.php\"> view user</a></strong>
	 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	 <strong><a href=\"login.php\">Admin Home</a>&emsp;
	 <a href=\"signout.php\">Signout</a></strong>&emsp;&emsp;
	 </div></h4>";
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
		</td>
	
  </tr>
  
</table>
